
create procedure DoctorsReport_SP
as
select *from Doctors




