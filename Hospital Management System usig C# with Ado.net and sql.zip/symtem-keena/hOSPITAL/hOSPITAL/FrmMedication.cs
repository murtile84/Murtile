﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hOSPITAL
{
    public partial class FrmMedication : Form
    {
        public int DrID { get; set; }
        public int PatientID { get; set; }
        public int MedicationID { get; set; }
       
        public FrmMedication()
        {
            InitializeComponent();
        }
        private void DeleteRecord()
        {
        }
        private void displMedSList()
        {
            using (SqlConnection conn = mainClass.connect())

            {
                SqlDataAdapter DA = new SqlDataAdapter("Select *from Medication_VW", conn);
                DataTable dt = new DataTable();
                DA.Fill(dt);
                dgvdisplayMedList.DataSource = dt;

            }

        }

        private void FrmMedication_Load(object sender, EventArgs e)
        {
            FillcomoDrs();
            displMedSList();
        }
        private void FillcomoDrs()
        {

            CboDrName.Text = "";
            using (SqlConnection conn = mainClass.connect())
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 DrID, 'select Doctor' as Dr_name UNION ALL SELECT DrID,Dr_name FROM Doctors ", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CboDrName.ValueMember = "DrID";
                CboDrName.DisplayMember = "Dr_name";
                CboDrName.DataSource = dt;
            }
        }

        private void CboDrName_SelectedIndexChanged(object sender, EventArgs e)
        {

            CboPaientname.Text = "";
            using (SqlConnection conn = mainClass.connect())
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 patientID, 'select Patient' as Patient_name UNION ALL SELECT PatientID,Patient_name FROM Patient where  DrID='" + CboDrName.SelectedValue + "'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CboPaientname.ValueMember = "PatientID";
                CboPaientname.DisplayMember = "Patient_name";
                CboPaientname.DataSource = dt;

            }
        }

        private void CboPaientname_SelectedIndexChanged(object sender, EventArgs e)
        {
            PatientID = (int)CboPaientname.SelectedValue;
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                if (CboDrName.Text == "select Faculty" || CboPaientname.Text == "" || txtDosage.Text == "" || txtprice.Text=="")
                {
                    MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Medication_SP";
                cmd.Parameters.AddWithValue("@ID", "");
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@Med_name", txtMedName.Text);
                cmd.Parameters.AddWithValue("@Dosage", txtDosage.Text);
                cmd.Parameters.AddWithValue("@Price", txtprice.Text);
                cmd.Parameters.AddWithValue("@Type", "insert");
                cmd.ExecuteNonQuery();
                MessageBox.Show("NEw medical has been saved","Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displMedSList();
                ClerTexBox();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;
            }
        }
        private void ClerTexBox()
        {
            CboPaientname.Text = "";
            CboDrName.Text = "";
            txtMedName.Text = "";
            txtDosage.Clear();
            txtprice.Clear();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                if (CboDrName.Text == "select Faculty" || CboPaientname.Text == "" || txtDosage.Text == "" || txtprice.Text == "")
                {
                    MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Medication_SP";
                cmd.Parameters.AddWithValue("@ID", MedicationID);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@Med_name", txtMedName.Text);
                cmd.Parameters.AddWithValue("@Dosage", txtDosage.Text);
                cmd.Parameters.AddWithValue("@Price", txtprice.Text);
                cmd.Parameters.AddWithValue("@Type", "update");
                cmd.ExecuteNonQuery();
                MessageBox.Show("medical has been updated", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displMedSList();
                ClerTexBox();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;
            }
        }

       
        private void btndelete_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                if (CboDrName.Text == "select Faculty" || CboPaientname.Text == "" || txtDosage.Text == "" || txtprice.Text == "")
                {
                    MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                DialogResult result = MessageBox.Show("Are you sure want to delete this record", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    DeleteRecord();
                }
                else
                {
                    MessageBox.Show("Delete Operation Cencelled", "Cencelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                DeleteRecord();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Medication_SP";
                cmd.Parameters.AddWithValue("@ID", MedicationID);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@Med_name", txtMedName.Text);
                cmd.Parameters.AddWithValue("@Dosage", txtDosage.Text);
                cmd.Parameters.AddWithValue("@Price", txtprice.Text);
                cmd.Parameters.AddWithValue("@Type", "delete");
                cmd.ExecuteNonQuery();
                MessageBox.Show("medical has been deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                displMedSList();
                ClerTexBox();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;
            }
        }

        private void dgvdisplayMedList_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            MedicationID = (int)dgvdisplayMedList.CurrentRow.Cells[0].Value;
            CboDrName.Text = dgvdisplayMedList.CurrentRow.Cells[5].Value.ToString();
            CboPaientname.Text = dgvdisplayMedList.CurrentRow.Cells[3].Value.ToString();
            txtDosage.Text = dgvdisplayMedList.CurrentRow.Cells[6].Value.ToString();
            txtprice.Text = dgvdisplayMedList.CurrentRow.Cells[7].Value.ToString();
            txtMedName.Text = dgvdisplayMedList.CurrentRow.Cells[1].Value.ToString();
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btndelete.Enabled = true;
        }
    }
}
