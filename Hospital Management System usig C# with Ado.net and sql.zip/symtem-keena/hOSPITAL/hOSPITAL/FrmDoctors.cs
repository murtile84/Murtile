﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hOSPITAL
{
    public partial class FrmDoctors : Form
    {
        public FrmDoctors()
        {
            InitializeComponent();
        }
        public int DoctorID { get; set; }
        private void DeleteRecord()
        {
        }

        private void FrmDoctors_Load(object sender, EventArgs e)
        {
            displDCRSList();

        }
        private void displDCRSList()
        {
            using (SqlConnection conn = mainClass.connect())

            {
                SqlDataAdapter DA = new SqlDataAdapter("Select *from Doctors", conn);
                DataTable dt = new DataTable();
                DA.Fill(dt);
               dgvdisplayDRSList.DataSource = dt;

            }

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtDrname.Text == "" || cbDRosex.Text == "" || TXTDrphone.Text == "" || CBOSpeciality.Text == "")
            {
                MessageBox.Show("flease fill the blank text input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Doctors_sp";
                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@Name", txtDrname.Text);
                cmd.Parameters.AddWithValue("@Sex", cbDRosex.Text);
                cmd.Parameters.AddWithValue("@Phone", TXTDrphone.Text);
                cmd.Parameters.AddWithValue("@Speciality", CBOSpeciality.Text);
                cmd.Parameters.AddWithValue("@Type", "INSERT");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Doctor has been registered", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clearTexbox();
                displDCRSList();
                btnsave.Enabled = true;
                btnupdate.Enabled = false;
                btndelete.Enabled = false;
            }
        }

        private void clearTexbox()
        {
            txtDrname.Clear();
            cbDRosex.Text="";
            TXTDrphone.Clear();
            CBOSpeciality.Text = "";
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtDrname.Text == "" || cbDRosex.Text == "" || TXTDrphone.Text == "" || CBOSpeciality.Text == "")
            {
                MessageBox.Show("flease fill the blank text input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Doctors_sp";
                cmd.Parameters.AddWithValue("@id", DoctorID);
                cmd.Parameters.AddWithValue("@Name", txtDrname.Text);
                cmd.Parameters.AddWithValue("@Sex", cbDRosex.Text);
                cmd.Parameters.AddWithValue("@Phone", TXTDrphone.Text);
                cmd.Parameters.AddWithValue("@Speciality", CBOSpeciality.Text);
                cmd.Parameters.AddWithValue("@Type", "update");
                cmd.ExecuteNonQuery();
                MessageBox.Show("A Doctor has been updated", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clearTexbox();
                displDCRSList();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtDrname.Text == "" || cbDRosex.Text == "" || TXTDrphone.Text == "" || CBOSpeciality.Text == "")
            {
                MessageBox.Show("flease fill the blank text input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure want to delete this record", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DeleteRecord();
            }
            else
            {
                MessageBox.Show("Delete Operation Cencelled", "Cencelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DeleteRecord();
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Doctors_sp";
                cmd.Parameters.AddWithValue("@id", DoctorID);
                cmd.Parameters.AddWithValue("@Name", txtDrname.Text);
                cmd.Parameters.AddWithValue("@Sex", cbDRosex.Text);
                cmd.Parameters.AddWithValue("@Phone", TXTDrphone.Text);
                cmd.Parameters.AddWithValue("@Speciality", CBOSpeciality.Text);
                cmd.Parameters.AddWithValue("@Type", "Delete");
                cmd.ExecuteNonQuery();
                MessageBox.Show("A Doctor has been deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clearTexbox();
                displDCRSList();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;
            }
        }

        private void dgvdisplayDRSList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DoctorID = (int)dgvdisplayDRSList.CurrentRow.Cells[0].Value;
            txtDrname.Text = dgvdisplayDRSList.CurrentRow.Cells[1].Value.ToString();
            cbDRosex.Text = dgvdisplayDRSList.CurrentRow.Cells[2].Value.ToString();
            TXTDrphone.Text = dgvdisplayDRSList.CurrentRow.Cells[3].Value.ToString();
            CBOSpeciality.Text = dgvdisplayDRSList.CurrentRow.Cells[4].Value.ToString();
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btndelete.Enabled = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
