﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hOSPITAL
{
    public partial class FRMUSER : Form
    {
        public String UserID { get; set; }
        public FRMUSER()
        {
            InitializeComponent();
        }
        private void DeleteRecord()
        {
        }

        private void FRMUSER_Load(object sender, EventArgs e)
        {
            DisplayUserList();
            btnsave.Enabled = true;
            btnupdate.Enabled = false;
            btndelete.Enabled = false;
        }
        private void DisplayUserList()
        {
            
            using (SqlConnection conn = mainClass.connect())
            {
                SqlDataAdapter da = new SqlDataAdapter("Select *from users", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvdisplayList.DataSource = dt;
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtFname.Text == "" || txtLname.Text == "" || TxtUsername.Text == "" || txtPassword.Text == "" || txtcomfirm.Text == "" || cbotxtusertype.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (txtPassword.Text != txtcomfirm.Text)
            {
                MessageBox.Show("Password didn't mutch", "Error Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Users_sp";
                cmd.Parameters.AddWithValue("@userID", "");
                cmd.Parameters.AddWithValue("@Fname", txtFname.Text);
                cmd.Parameters.AddWithValue("@Lname", txtLname.Text);
                cmd.Parameters.AddWithValue("@Username", TxtUsername.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@Usertype", cbotxtusertype.Text);
                cmd.Parameters.AddWithValue("@type", "Insert");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New user has been registered thanks!", "saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisplayUserList();
                ClearTextBox();
            }
        }
        private void ClearTextBox()
        {
            txtFname.Clear();
            txtLname.Clear();
            TxtUsername.Clear();
            txtPassword.Clear();
            txtcomfirm.Clear();
            cbotxtusertype.Text = "";
        }

        private void dgvdisplayList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            UserID = dgvdisplayList.CurrentRow.Cells[0].Value.ToString();
            txtFname.Text = dgvdisplayList.CurrentRow.Cells[1].Value.ToString();
            txtLname.Text = dgvdisplayList.CurrentRow.Cells[2].Value.ToString();
            TxtUsername.Text = dgvdisplayList.CurrentRow.Cells[3].Value.ToString();
            txtPassword.Text = dgvdisplayList.CurrentRow.Cells[4].Value.ToString();
            txtcomfirm.Text = txtPassword.Text;
            cbotxtusertype.Text = dgvdisplayList.CurrentRow.Cells[5].Value.ToString();
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btndelete.Enabled = true;
            TxtUsername.ReadOnly = true;
            txtPassword.ReadOnly = true;
            txtcomfirm.ReadOnly = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            if (txtFname.Text == "" || txtLname.Text == "" || TxtUsername.Text == "" || txtPassword.Text == "" || txtcomfirm.Text == "" || cbotxtusertype.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (txtPassword.Text != txtcomfirm.Text)
            {
                MessageBox.Show("Password didn't mutch", "Error Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Users_sp";
                cmd.Parameters.AddWithValue("@userID", UserID);
                cmd.Parameters.AddWithValue("@Fname", txtFname.Text);
                cmd.Parameters.AddWithValue("@Lname", txtLname.Text);
                cmd.Parameters.AddWithValue("@Username", TxtUsername.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@Usertype", cbotxtusertype.Text);
                cmd.Parameters.AddWithValue("@type", "UPDATE");
                cmd.ExecuteNonQuery();
                MessageBox.Show("The user has been updated thanks!", "updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisplayUserList();
                ClearTextBox();
                btnsave.Enabled = true;
                btnupdate.Enabled = false;
                btndelete.Enabled = false;
                TxtUsername.ReadOnly = false;
                txtPassword.ReadOnly = false;
                txtcomfirm.ReadOnly = false;
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtFname.Text == "" || txtLname.Text == "" || TxtUsername.Text == "" || txtPassword.Text == "" || txtcomfirm.Text == "" || cbotxtusertype.Text == "")
            {
                MessageBox.Show("Please fill the blank input field", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (txtPassword.Text != txtcomfirm.Text)
            {
                MessageBox.Show("Password didn't mutch", "Error Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure want to delete this record", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DeleteRecord();
            }
            else
            {
                MessageBox.Show("Delete Operation Cencelled", "Cencelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DeleteRecord();

            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Users_sp";
                cmd.Parameters.AddWithValue("@userID", UserID);
                cmd.Parameters.AddWithValue("@Fname", txtFname.Text);
                cmd.Parameters.AddWithValue("@Lname", txtLname.Text);
                cmd.Parameters.AddWithValue("@Username", TxtUsername.Text);
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                cmd.Parameters.AddWithValue("@Usertype", cbotxtusertype.Text);
                cmd.Parameters.AddWithValue("@type", "DELETE");
                cmd.ExecuteNonQuery();
                MessageBox.Show("The user has been deleted thanks!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DisplayUserList();
                ClearTextBox();
                btnsave.Enabled = true;
                btnupdate.Enabled = false;
                btndelete.Enabled = false;
                TxtUsername.ReadOnly = false;
                txtPassword.ReadOnly = false;
                txtcomfirm.ReadOnly = false;
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())

            {
                SqlDataAdapter DA = new SqlDataAdapter("select  *from users where First_name like'" + txtsearch.Text + "%'", conn);
                DataTable dt = new DataTable();
                DA.Fill(dt);
                dgvdisplayList.DataSource = dt;

            }
        }
}
}
