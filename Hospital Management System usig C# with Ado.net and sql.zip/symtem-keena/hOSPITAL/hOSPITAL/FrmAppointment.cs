﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hOSPITAL
{
    public partial class FrmAppointment : Form
    {
        public int DrID { get; set; }
        public int PatientID { get; set; }
        public int AppointmentID { get; set; }
        public FrmAppointment()
        {
            InitializeComponent();
        }
        private void DeleteRecord()
        {
        }
        private void displayAppList()
        {
            using (SqlConnection conn = mainClass.connect())

            {
                SqlDataAdapter DA = new SqlDataAdapter("select *from Appointment_Vw", conn);
                DataTable dt = new DataTable();
                DA.Fill(dt);
                dgvdisplayAppList.DataSource = dt;

            }

        }


        private void btndelete_Click(object sender, EventArgs e)
        {

            if (CboDrName.Text == "select a doctor" || CboPaientname.Text == "" || txtStatus.Text == "")
            {
                MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure want to delete this record", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DeleteRecord();
            }
            else
            {
                MessageBox.Show("Delete Operation Cencelled", "Cencelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DeleteRecord();
            using (SqlConnection conn = mainClass.connect())
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "App_sp";
                cmd.Parameters.AddWithValue("@AppointmentID", AppointmentID);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@Status", txtStatus.Text);
                cmd.Parameters.AddWithValue("@Type", "delete");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Department has been deleted Thanks! ", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                displayAppList();
            }

        }

    

        private void FrmAppointment_Load(object sender, EventArgs e)
        {
            fillcomdrs();
            displayAppList();
        }
        private void fillcomdrs()
        {
            CboDrName.Text = "";
            using (SqlConnection conn = mainClass.connect())
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 DrID, 'select Doctor' as Dr_name UNION ALL SELECT DrID,Dr_name FROM Doctors ", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CboDrName.ValueMember = "DrID";
                CboDrName.DisplayMember = "Dr_name";
                CboDrName.DataSource = dt;
            }
        }
        private void CboDrName_SelectedIndexChanged(object sender, EventArgs e)
        {
            CboPaientname.Text = "";
            using (SqlConnection conn = mainClass.connect())
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 patientID, 'select Patient' as Patient_name UNION ALL SELECT PatientID,Patient_name FROM Patient where  DrID='" + CboDrName.SelectedValue + "'", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CboPaientname.ValueMember = "PatientID";
                CboPaientname.DisplayMember = "Patient_name";
                CboPaientname.DataSource = dt;

            }
        }

        private void CboPaientname_SelectedIndexChanged(object sender, EventArgs e)
        {
            PatientID = (int)CboPaientname.SelectedValue;

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (CboDrName.Text == "select a doctor" || CboPaientname.Text == "" || txtStatus.Text == "")
            {
                MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "App_sp";
                cmd.Parameters.AddWithValue("@AppointmentID", "");
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@Status", txtStatus.Text);
                cmd.Parameters.AddWithValue("@Type", "insert");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Department has been registered Thanks! ", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displayAppList();
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            if (CboDrName.Text == "select a doctor" || CboPaientname.Text == "" || txtStatus.Text == "")
            {
                MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "App_sp";
                cmd.Parameters.AddWithValue("@AppointmentID", AppointmentID);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@Status", txtStatus.Text);
                cmd.Parameters.AddWithValue("@Type", "update");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Department has been Updated Thanks! ", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displayAppList();
            }
        }

        private void dgvdisplayAppList_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            AppointmentID= (int)dgvdisplayAppList.CurrentRow.Cells[0].Value;
            CboDrName.Text = dgvdisplayAppList.CurrentRow.Cells[4].Value.ToString();
            CboPaientname.Text = dgvdisplayAppList.CurrentRow.Cells[2].Value.ToString();
            txtStatus.Text = dgvdisplayAppList.CurrentRow.Cells[5].Value.ToString();
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btndelete.Enabled = true;
        }
    }
}
