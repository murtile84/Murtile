﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hOSPITAL
{
    public partial class fRMmain : Form
    {
        public fRMmain()
        {
            InitializeComponent();
        }

        private void addEditUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FRMUSER frm = new FRMUSER();
            frm.Show();
            frm.MdiParent = this;

        }

        private void fRMmain_Load(object sender, EventArgs e)
        {

        }

        private void addEditPatentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPatient frm = new FrmPatient();
            frm.Show();
            frm.MdiParent = this;
        }

        private void addEditDoctorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmDoctors frm = new FrmDoctors();
            frm.Show();
            frm.MdiParent = this;
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogoin frm = new frmLogoin();
            frm.Show();
        }

        private void addEditMedicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAppointment frm = new FrmAppointment();
            frm.Show();
            frm.MdiParent = this;
        }

        private void makePaymenyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMedication frm = new FrmMedication();
            frm.Show();
            frm.MdiParent = this;
        }

        private void makePaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPayment frm = new FrmPayment();
            frm.Show();
            frm.MdiParent = this;
        }

        private void medicalReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MedicationReport_sp";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CrystalReportMedication cr = new CrystalReportMedication();
                cr.SetDataSource(dt);
                FrmReport frm = new FrmReport();
                frm.crptRViewer.ReportSource = cr;
                frm.Show();
            }
        }

        private void paymentReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "paymentReport_Sp";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
               CrystalPaymentReport cr = new CrystalPaymentReport();
                cr.SetDataSource(dt);
                FrmReport frm = new FrmReport();
                frm.crptRViewer.ReportSource = cr;
                frm.Show();
            }
        }

        private void doctorReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DoctorsReport_SP";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                DoctorsReport_crpt cr = new DoctorsReport_crpt();
                cr.SetDataSource(dt);
                FrmReport frm = new FrmReport();
                frm.crptRViewer.ReportSource = cr;
                frm.Show();
            }

        }

        private void patientReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "PatientsReport_SP";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                PatientsReport_Crpt cr = new PatientsReport_Crpt();
                cr.SetDataSource(dt);
                FrmReport frm = new FrmReport();
                frm.crptRViewer.ReportSource = cr;
                frm.Show();
            }
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
