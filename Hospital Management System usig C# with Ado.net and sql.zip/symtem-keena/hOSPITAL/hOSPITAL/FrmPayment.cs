﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hOSPITAL
{
    public partial class FrmPayment : Form
    {
        public int PaymentID { get; set; }
        public FrmPayment()
        {
            InitializeComponent();
        }
        private void DeleteRecord()
        {
        }
        private void displayPaymentList()
        {
            using (SqlConnection conn = mainClass.connect())

            {
                SqlDataAdapter DA = new SqlDataAdapter("select *from payment_VW", conn);
                DataTable dt = new DataTable();
                DA.Fill(dt);
                dgvdisplayPaymentList.DataSource = dt;
            }
        }

        private void FrmPayment_Load(object sender, EventArgs e)
        {
            fillcomboPatient();
            displayPaymentList();
        }
        private void fillcomboPatient()
        {
            CboPaientname.Text = "";
            using (SqlConnection conn = mainClass.connect())
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 patientID, 'select Patient' as Patient_name UNION ALL SELECT PatientID,Patient_name FROM Patient", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CboPaientname.ValueMember = "PatientID";
                CboPaientname.DisplayMember = "Patient_name";
                CboPaientname.DataSource = dt;

            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            if (CboPaientname.Text == "select Faculty" || txtpaidAmount.Text=="")
            {
                MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Payment_SP";
                cmd.Parameters.AddWithValue("@Payment_Id","");
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@PaidAmount", txtpaidAmount.Text);
                cmd.Parameters.AddWithValue("@Payment_Date", PaymentDate.Text);
                cmd.Parameters.AddWithValue("@Type", "insert");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New payment has been registered Thanks! ", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
               displayPaymentList();
            }

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (CboPaientname.Text == "select Faculty" || txtpaidAmount.Text == "")
            {
                MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DialogResult result = MessageBox.Show("Are you sure want to delete this record", "Delete Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                DeleteRecord();
            }
            else
            {
                MessageBox.Show("Delete Operation Cencelled", "Cencelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DeleteRecord();
            using (SqlConnection conn = mainClass.connect())
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Payment_SP";
                cmd.Parameters.AddWithValue("@Payment_Id", PaymentID);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@PaidAmount", txtpaidAmount.Text);
                cmd.Parameters.AddWithValue("@Payment_Date", PaymentDate.Text);
                cmd.Parameters.AddWithValue("@Type", "delete");
                cmd.ExecuteNonQuery();
                MessageBox.Show("The payment has been deleted Thanks! ", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displayPaymentList();
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (CboPaientname.Text == "select Faculty" ||  txtpaidAmount.Text == "")
            {
                MessageBox.Show("please fill the blank space", "Error Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Payment_SP";
                cmd.Parameters.AddWithValue("@Payment_Id", PaymentID);
                cmd.Parameters.AddWithValue("@PatientID", CboPaientname.SelectedValue);
                cmd.Parameters.AddWithValue("@PaidAmount", txtpaidAmount.Text);
                cmd.Parameters.AddWithValue("@Payment_Date", PaymentDate.Text);
                cmd.Parameters.AddWithValue("@Type", "Update");
                cmd.ExecuteNonQuery();
                MessageBox.Show("The payment has been updated Thanks! ", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                displayPaymentList();
            }
        }

        private void dgvdisplayPaymentList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            PaymentID = (int)dgvdisplayPaymentList.CurrentRow.Cells[0].Value;
            CboPaientname.Text = dgvdisplayPaymentList.CurrentRow.Cells[2].Value.ToString();
            txtpaidAmount.Text = dgvdisplayPaymentList.CurrentRow.Cells[3].Value.ToString();
            PaymentDate.Text = dgvdisplayPaymentList.CurrentRow.Cells[4].Value.ToString();
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btndelete.Enabled = true;
        }
    }
}
