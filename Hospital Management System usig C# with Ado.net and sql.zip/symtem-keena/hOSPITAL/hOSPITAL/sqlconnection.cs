﻿namespace hOSPITAL
{
    internal class sqlconnection
    {
    }
}