﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hOSPITAL
{
    class mainClass
    {
        public static SqlConnection connect()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-IUIANCQ\\MSSQLSERVER13;Initial Catalog=Hospital; Integrated Security=True");
            conn.Open();
            return conn;
        }
    }
}
