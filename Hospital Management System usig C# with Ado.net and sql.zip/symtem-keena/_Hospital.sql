use Hospital
go
create table users
(
userID int primary key identity,
Fnmae varchar(50) not null,
Lname varchar(50) not null,
Username varchar(50) not null,
Password varchar(50) not null,
Usertype varchar(30) not null,
)

Go
create table Doctors
(
DrID int primary key identity,
Dr_name varchar(50)  not null,
Sex varchar(10) not null,
Phone int unique not null,
Speciality varchar(50) not null,
AddedDate date default getdate() not null, 
)
Go
create table patient
(
patientID int primary key Identity,
DrID int foreign key references Doctors(DrID),
Patient_name varchar(50) not null,
Age int not null,
mobile int Unique not null,
sex varchar(10) not null,
Address varchar(50) not null,
AddedDate date default getdate() not null, 
)
Go

create table Appointment
(
AppointmentID int primary key identity,
patientID int foreign key references patient(patientID),
DrID int foreign key references Doctors(DrID),
AppointmentDate Datetime default getdate() not null,
Status varchar(50) default 'Completed' NOT NULL
)
Go
create table Medication
(
Med_ID int primary key identity,
patientID int foreign key references patient(patientID),
DrID int foreign key references Doctors(DrID),
Med_name varchar(50) not null,
Dosage int not null,
price decimal (10,2)
)
Go
create table  payment
(
Peyment_Id int primary key identity,
patientID int foreign key references patient(patientID),
paidAmount decimal (10,2),
Payment_Date date default getdate() not null
)
