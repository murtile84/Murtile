Alter view Appointment_Vw
As
SELECT 
    A.AppointmentID,
    P.PatientID,
    P.Patient_name AS PatientName,
    D.DrID,
    D.Dr_name AS DoctorName,
	 A.Status,
	 A.AppointmentDate
FROM Appointment A
INNER JOIN Patient P ON A.PatientID = P.PatientID
INNER JOIN Doctors D ON A.DrID�=�D.DrID;
delete Appointment