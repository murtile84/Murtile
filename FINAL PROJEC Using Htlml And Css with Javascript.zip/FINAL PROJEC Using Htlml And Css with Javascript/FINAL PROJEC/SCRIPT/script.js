let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>{
    loginForm.classList.toggle('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    loginForm.classList.remove('active');
}

window.onscroll = () =>{
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}// Event listener for the login form submission
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevents form from submitting

    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    let errorMessage = document.getElementById('error-message');

    // Form validation
    if (username === "" || password === "") {
        errorMessage.textContent = "Please fill in all fields.";
        return;
    }

    // Clear error message if validation passes
    errorMessage.textContent = "";

    // Handle form submission
    alert('Form submitted successfully');
});

// Event listener for the menu button
document.getElementById('menu-btn').addEventListener('click', function() {
    alert('Menu button clicked');
});
