﻿namespace hOSPITAL
{
    partial class fRMmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.manageUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditUsersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditPatentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditDoctorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.medicationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEditMedicationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makePaymenyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.makePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patientReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.medicalReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Font = new System.Drawing.Font("Cambria", 16F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manageUsersToolStripMenuItem,
            this.paiToolStripMenuItem,
            this.doctorsToolStripMenuItem,
            this.medicationsToolStripMenuItem,
            this.paymentToolStripMenuItem,
            this.paymentToolStripMenuItem1,
            this.reportsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1010, 34);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // manageUsersToolStripMenuItem
            // 
            this.manageUsersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditUsersToolStripMenuItem,
            this.changePasswordToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.manageUsersToolStripMenuItem.Name = "manageUsersToolStripMenuItem";
            this.manageUsersToolStripMenuItem.Size = new System.Drawing.Size(153, 30);
            this.manageUsersToolStripMenuItem.Text = "Manage users";
            // 
            // addEditUsersToolStripMenuItem
            // 
            this.addEditUsersToolStripMenuItem.Name = "addEditUsersToolStripMenuItem";
            this.addEditUsersToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.addEditUsersToolStripMenuItem.Text = "Add/Edit Users";
            this.addEditUsersToolStripMenuItem.Click += new System.EventHandler(this.addEditUsersToolStripMenuItem_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.changePasswordToolStripMenuItem.Text = "Change password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(254, 30);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // paiToolStripMenuItem
            // 
            this.paiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditPatentsToolStripMenuItem});
            this.paiToolStripMenuItem.Name = "paiToolStripMenuItem";
            this.paiToolStripMenuItem.Size = new System.Drawing.Size(100, 30);
            this.paiToolStripMenuItem.Text = "Patients";
            // 
            // addEditPatentsToolStripMenuItem
            // 
            this.addEditPatentsToolStripMenuItem.Name = "addEditPatentsToolStripMenuItem";
            this.addEditPatentsToolStripMenuItem.Size = new System.Drawing.Size(250, 30);
            this.addEditPatentsToolStripMenuItem.Text = "Add/Edit patents";
            this.addEditPatentsToolStripMenuItem.Click += new System.EventHandler(this.addEditPatentsToolStripMenuItem_Click);
            // 
            // doctorsToolStripMenuItem
            // 
            this.doctorsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditDoctorsToolStripMenuItem});
            this.doctorsToolStripMenuItem.Name = "doctorsToolStripMenuItem";
            this.doctorsToolStripMenuItem.Size = new System.Drawing.Size(98, 30);
            this.doctorsToolStripMenuItem.Text = "Doctors";
            // 
            // addEditDoctorsToolStripMenuItem
            // 
            this.addEditDoctorsToolStripMenuItem.Name = "addEditDoctorsToolStripMenuItem";
            this.addEditDoctorsToolStripMenuItem.Size = new System.Drawing.Size(255, 30);
            this.addEditDoctorsToolStripMenuItem.Text = "Add/Edit Doctors";
            this.addEditDoctorsToolStripMenuItem.Click += new System.EventHandler(this.addEditDoctorsToolStripMenuItem_Click);
            // 
            // medicationsToolStripMenuItem
            // 
            this.medicationsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEditMedicationsToolStripMenuItem});
            this.medicationsToolStripMenuItem.Name = "medicationsToolStripMenuItem";
            this.medicationsToolStripMenuItem.Size = new System.Drawing.Size(147, 30);
            this.medicationsToolStripMenuItem.Text = "Appointment";
            // 
            // addEditMedicationsToolStripMenuItem
            // 
            this.addEditMedicationsToolStripMenuItem.Name = "addEditMedicationsToolStripMenuItem";
            this.addEditMedicationsToolStripMenuItem.Size = new System.Drawing.Size(304, 30);
            this.addEditMedicationsToolStripMenuItem.Text = "Add/Edit Appointment";
            this.addEditMedicationsToolStripMenuItem.Click += new System.EventHandler(this.addEditMedicationsToolStripMenuItem_Click);
            // 
            // paymentToolStripMenuItem
            // 
            this.paymentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.makePaymenyToolStripMenuItem});
            this.paymentToolStripMenuItem.Name = "paymentToolStripMenuItem";
            this.paymentToolStripMenuItem.Size = new System.Drawing.Size(138, 30);
            this.paymentToolStripMenuItem.Text = "Medications";
            // 
            // makePaymenyToolStripMenuItem
            // 
            this.makePaymenyToolStripMenuItem.Name = "makePaymenyToolStripMenuItem";
            this.makePaymenyToolStripMenuItem.Size = new System.Drawing.Size(295, 30);
            this.makePaymenyToolStripMenuItem.Text = "Add/Edit Medications";
            this.makePaymenyToolStripMenuItem.Click += new System.EventHandler(this.makePaymenyToolStripMenuItem_Click);
            // 
            // paymentToolStripMenuItem1
            // 
            this.paymentToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.makePaymentToolStripMenuItem});
            this.paymentToolStripMenuItem1.Name = "paymentToolStripMenuItem1";
            this.paymentToolStripMenuItem1.Size = new System.Drawing.Size(107, 30);
            this.paymentToolStripMenuItem1.Text = "Payment";
            // 
            // makePaymentToolStripMenuItem
            // 
            this.makePaymentToolStripMenuItem.Name = "makePaymentToolStripMenuItem";
            this.makePaymentToolStripMenuItem.Size = new System.Drawing.Size(228, 30);
            this.makePaymentToolStripMenuItem.Text = "Make payment";
            this.makePaymentToolStripMenuItem.Click += new System.EventHandler(this.makePaymentToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.patientReportsToolStripMenuItem,
            this.doctorReportsToolStripMenuItem,
            this.medicalReportsToolStripMenuItem,
            this.paymentReportsToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(98, 30);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // patientReportsToolStripMenuItem
            // 
            this.patientReportsToolStripMenuItem.Name = "patientReportsToolStripMenuItem";
            this.patientReportsToolStripMenuItem.Size = new System.Drawing.Size(246, 30);
            this.patientReportsToolStripMenuItem.Text = "Patient reports";
            this.patientReportsToolStripMenuItem.Click += new System.EventHandler(this.patientReportsToolStripMenuItem_Click);
            // 
            // doctorReportsToolStripMenuItem
            // 
            this.doctorReportsToolStripMenuItem.Name = "doctorReportsToolStripMenuItem";
            this.doctorReportsToolStripMenuItem.Size = new System.Drawing.Size(246, 30);
            this.doctorReportsToolStripMenuItem.Text = "Doctor Reports";
            this.doctorReportsToolStripMenuItem.Click += new System.EventHandler(this.doctorReportsToolStripMenuItem_Click);
            // 
            // medicalReportsToolStripMenuItem
            // 
            this.medicalReportsToolStripMenuItem.Name = "medicalReportsToolStripMenuItem";
            this.medicalReportsToolStripMenuItem.Size = new System.Drawing.Size(246, 30);
            this.medicalReportsToolStripMenuItem.Text = "Medical Reports";
            this.medicalReportsToolStripMenuItem.Click += new System.EventHandler(this.medicalReportsToolStripMenuItem_Click);
            // 
            // paymentReportsToolStripMenuItem
            // 
            this.paymentReportsToolStripMenuItem.Name = "paymentReportsToolStripMenuItem";
            this.paymentReportsToolStripMenuItem.Size = new System.Drawing.Size(246, 30);
            this.paymentReportsToolStripMenuItem.Text = "Payment reports";
            this.paymentReportsToolStripMenuItem.Click += new System.EventHandler(this.paymentReportsToolStripMenuItem_Click);
            // 
            // fRMmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1010, 404);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fRMmain";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.fRMmain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem manageUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEditUsersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEditPatentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEditDoctorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem medicationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEditMedicationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makePaymenyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem makePaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patientReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctorReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem medicalReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentReportsToolStripMenuItem;
    }
}

