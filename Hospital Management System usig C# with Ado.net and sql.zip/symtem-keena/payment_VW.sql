alter view payment_VW
as
SELECT 
    Pay.Peyment_Id,
	P.PatientID,
    P.Patient_name AS PatientName,
    Pay.PaidAmount,
    Pay.Payment_Date
FROM Payment Pay
INNER JOIN Patient P ON Pay.PatientID =�P.PatientID
