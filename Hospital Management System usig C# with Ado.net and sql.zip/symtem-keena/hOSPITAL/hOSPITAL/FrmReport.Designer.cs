﻿namespace hOSPITAL
{
    partial class FrmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crptRViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // crptRViewer
            // 
            this.crptRViewer.ActiveViewIndex = -1;
            this.crptRViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crptRViewer.Cursor = System.Windows.Forms.Cursors.Default;
            this.crptRViewer.DisplayStatusBar = false;
            this.crptRViewer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crptRViewer.Location = new System.Drawing.Point(0, 0);
            this.crptRViewer.Name = "crptRViewer";
            this.crptRViewer.ShowCopyButton = false;
            this.crptRViewer.ShowGotoPageButton = false;
            this.crptRViewer.ShowGroupTreeButton = false;
            this.crptRViewer.ShowLogo = false;
            this.crptRViewer.Size = new System.Drawing.Size(897, 423);
            this.crptRViewer.TabIndex = 0;
            this.crptRViewer.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            this.crptRViewer.Load += new System.EventHandler(this.crystalReportViewer1_Load);
            // 
            // FrmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 423);
            this.Controls.Add(this.crptRViewer);
            this.Name = "FrmReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmReport";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmReport_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer crptRViewer;
    }
}