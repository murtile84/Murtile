create procedure MedicationReport_sp
As
SELECT 
    M.Med_ID,
    Med_name,
	P.PatientID,
    P.Patient_name AS PatientName,
	    D.DrID,
    D.Dr_name AS DoctorName,
	m.Dosage,
    price
FROM Medication M
INNER JOIN Patient P ON M.PatientID = P.PatientID
INNER JOIN Doctors D ON M.DrID�=�D.DrID


