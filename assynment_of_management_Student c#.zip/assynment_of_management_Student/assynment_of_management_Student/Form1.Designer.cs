﻿namespace assynment_of_management_Student
{
    partial class student_management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stdgropbox = new System.Windows.Forms.GroupBox();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.clearbutton = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.Extra_curricular = new System.Windows.Forms.CheckBox();
            this.listcourse = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.radiofemale = new System.Windows.Forms.RadioButton();
            this.radiomale = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.num_age = new System.Windows.Forms.TextBox();
            this.txtstudentName = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.stdgropbox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // stdgropbox
            // 
            this.stdgropbox.BackColor = System.Drawing.Color.Aqua;
            this.stdgropbox.Controls.Add(this.ResultLabel);
            this.stdgropbox.Controls.Add(this.clearbutton);
            this.stdgropbox.Controls.Add(this.exitbutton);
            this.stdgropbox.Controls.Add(this.submitButton);
            this.stdgropbox.Controls.Add(this.Extra_curricular);
            this.stdgropbox.Controls.Add(this.listcourse);
            this.stdgropbox.Controls.Add(this.groupBox1);
            this.stdgropbox.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stdgropbox.Location = new System.Drawing.Point(74, 71);
            this.stdgropbox.Name = "stdgropbox";
            this.stdgropbox.Size = new System.Drawing.Size(453, 447);
            this.stdgropbox.TabIndex = 0;
            this.stdgropbox.TabStop = false;
            this.stdgropbox.Text = "Student Management";
            // 
            // ResultLabel
            // 
            this.ResultLabel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ResultLabel.Location = new System.Drawing.Point(34, 307);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(285, 131);
            this.ResultLabel.TabIndex = 11;
            this.ResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ResultLabel.Click += new System.EventHandler(this.ResultLabel_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.BackColor = System.Drawing.Color.DodgerBlue;
            this.clearbutton.Location = new System.Drawing.Point(106, 270);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(80, 34);
            this.clearbutton.TabIndex = 9;
            this.clearbutton.Text = "c&lear";
            this.clearbutton.UseVisualStyleBackColor = false;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.BackColor = System.Drawing.Color.CornflowerBlue;
            this.exitbutton.Location = new System.Drawing.Point(178, 270);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(75, 34);
            this.exitbutton.TabIndex = 10;
            this.exitbutton.Text = "E&xit";
            this.exitbutton.UseVisualStyleBackColor = false;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.submitButton.Location = new System.Drawing.Point(37, 270);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(75, 34);
            this.submitButton.TabIndex = 8;
            this.submitButton.Text = "s&ubmit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // Extra_curricular
            // 
            this.Extra_curricular.AutoSize = true;
            this.Extra_curricular.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Extra_curricular.Location = new System.Drawing.Point(178, 205);
            this.Extra_curricular.Name = "Extra_curricular";
            this.Extra_curricular.Size = new System.Drawing.Size(115, 17);
            this.Extra_curricular.TabIndex = 7;
            this.Extra_curricular.Text = "Extra-curricular";
            this.Extra_curricular.UseVisualStyleBackColor = false;
            // 
            // listcourse
            // 
            this.listcourse.FormattingEnabled = true;
            this.listcourse.Items.AddRange(new object[] {
            "JAVA",
            "C#",
            "HTML & CSS3",
            "React"});
            this.listcourse.Location = new System.Drawing.Point(37, 195);
            this.listcourse.Name = "listcourse";
            this.listcourse.Size = new System.Drawing.Size(135, 69);
            this.listcourse.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.radiofemale);
            this.groupBox1.Controls.Add(this.radiomale);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtStudentID);
            this.groupBox1.Controls.Add(this.num_age);
            this.groupBox1.Controls.Add(this.txtstudentName);
            this.groupBox1.Location = new System.Drawing.Point(37, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(346, 142);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupstudentinfo";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(49, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 21);
            this.label2.TabIndex = 9;
            this.label2.Text = "Student Name:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(49, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 21);
            this.label1.TabIndex = 8;
            this.label1.Text = "Student ID:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // radiofemale
            // 
            this.radiofemale.AutoSize = true;
            this.radiofemale.Location = new System.Drawing.Point(273, 115);
            this.radiofemale.Name = "radiofemale";
            this.radiofemale.Size = new System.Drawing.Size(64, 17);
            this.radiofemale.TabIndex = 5;
            this.radiofemale.TabStop = true;
            this.radiofemale.Text = "female";
            this.radiofemale.UseVisualStyleBackColor = true;
            // 
            // radiomale
            // 
            this.radiomale.AutoSize = true;
            this.radiomale.Location = new System.Drawing.Point(175, 115);
            this.radiomale.Name = "radiomale";
            this.radiomale.Size = new System.Drawing.Size(53, 17);
            this.radiomale.TabIndex = 4;
            this.radiomale.TabStop = true;
            this.radiomale.Text = "male";
            this.radiomale.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(49, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "Student Age:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtStudentID
            // 
            this.txtStudentID.Location = new System.Drawing.Point(187, 55);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.Size = new System.Drawing.Size(150, 21);
            this.txtStudentID.TabIndex = 1;
            // 
            // num_age
            // 
            this.num_age.Location = new System.Drawing.Point(187, 82);
            this.num_age.Name = "num_age";
            this.num_age.Size = new System.Drawing.Size(150, 21);
            this.num_age.TabIndex = 3;
            // 
            // txtstudentName
            // 
            this.txtstudentName.Location = new System.Drawing.Point(187, 28);
            this.txtstudentName.Name = "txtstudentName";
            this.txtstudentName.Size = new System.Drawing.Size(150, 21);
            this.txtstudentName.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = global::assynment_of_management_Student.Properties.Resources.sp;
            this.pictureBox1.Location = new System.Drawing.Point(180, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 67);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // student_management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(883, 518);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.stdgropbox);
            this.Name = "student_management";
            this.Text = "Student management";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.stdgropbox.ResumeLayout(false);
            this.stdgropbox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox stdgropbox;
        private System.Windows.Forms.Label ResultLabel;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.CheckBox Extra_curricular;
        private System.Windows.Forms.ListBox listcourse;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radiofemale;
        private System.Windows.Forms.RadioButton radiomale;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.TextBox num_age;
        private System.Windows.Forms.TextBox txtstudentName;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

