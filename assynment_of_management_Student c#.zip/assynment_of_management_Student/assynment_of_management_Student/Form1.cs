﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assynment_of_management_Student
{
    public partial class student_management : Form
    {
        public student_management()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            try
            {
               
                // Greating variables and get input values from controls
               string studentName = txtstudentName.Text;
               int studentID = int.Parse(txtStudentID.Text);
               int age = int.Parse(num_age.Text);
               string gender = radiomale.Checked ? "Male" : "Female";
               string courses = listcourse.Text;
               bool isExtraCurricular = Extra_curricular.Checked;

                

                // Display result in label
                //checking if age between 18 and 30
                if (age >= 18 && age <= 30)
                {
                        //if you checked female radiobutton display female gender
                        if (radiofemale.Checked)
                        {
                            //you must select a course
                             string course;
                          if (listcourse.SelectedIndex != -1)
                         {
                        course = listcourse.SelectedItem.ToString();
                        switch (course)
                        {
                            case "JAVA":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                            case "C#":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                            case "HTML & CSS3":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                            case "React":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;

                        }
                   
                            //ResultLabel.Text = "Name : " + studentName.ToString() + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\n " + "Gender : " +
                              //  gender + "\n" + "Courses : " + courses.ToString() + "\n" + "EXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                    }
                        //if you dont select course display this message
                    else
                    {
                        MessageBox.Show("You must select at least one course");
                    }
                        
                    }
                        //if you check male radio button display male gender
                        else if (radiomale.Checked)
                        {
                         //you must select a course
                            string course;
                        if (listcourse.SelectedIndex != -1)
                        {
                        course = listcourse.SelectedItem.ToString();
                        switch (course)
                        {
                            case "JAVA":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                            case "C#":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                            case "HTML & CSS3":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                            case "React":
                                ResultLabel.Text = "Name : " + studentName + "\nID : " + studentID.ToString() + "\nAge : " + age.ToString() + "\nGender : " +
                                gender + "\nCourses : " + courses.ToString() + "\nEXtracirricular : " + (isExtraCurricular ? "Yes" : "No");
                                break;
                        }
                     }
                    //if you dont select a course display this message
                    else
                    {
                        MessageBox.Show("You must select at least one course");
                    }
                     
                    }
                    

                            //if you don't check both male and female radio button display this message
                        else
                        {
                            MessageBox.Show("please select the gender");

                        
                }
                
            }

                    //if the age is not correct display this message
                else
                {
                    MessageBox.Show("The age must greater than 17 and less than 31");
                }
               

                    }
        
                
                   
                


            
            catch (Exception test)
            {
                MessageBox.Show(test.Message);
            }
            
          
        }

        private void clearbutton_Click(object sender, EventArgs e)
        {
           txtstudentName.Text=" ";
            txtStudentID.Clear();
            num_age.Text = " ";
            radiomale.Checked = false;
            radiofemale.Checked = false;
            listcourse.ClearSelected();
            Extra_curricular.Checked = false;
            ResultLabel.Text= string.Empty;
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResultLabel_Click(object sender, EventArgs e)
        {

        }

      
    }
}
