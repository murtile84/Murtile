// DOM Manipulation Example
const myButton = document.getElementById("myButton");
myButton.addEventListener("click", () => {
  const output = document.getElementById("output");
  output.innerText = "Button clicked! You can now see this text.";
});

// Form Validation Example
const form = document.getElementById("myForm");
form.addEventListener("submit", (event) => {
  const nameInput = document.getElementById("name");
  const emailInput = document.getElementById("email");
  if (nameInput.value === "" || emailInput.value === "") {
    alert("All fields are required!");
    event.preventDefault();
  } else if (!emailInput.value.includes("@")) {
    alert("Please enter a valid email address!");
    event.preventDefault();
  } else {
    alert("Form submitted successfully!");
  }
});