﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace hOSPITAL
{
    public partial class FrmPatient : Form
    {
        public int paitientID { get; set; } 
        public FrmPatient()
        {
            InitializeComponent();
        }
       

        private void FrmPatient_Load(object sender, EventArgs e)
        {
            displaypatientList();
            fillComboDrs();

        }
        private void fillComboDrs()
        {
            CboDrName.Text = "";
            using (SqlConnection conn = mainClass.connect())
            {

                SqlDataAdapter da = new SqlDataAdapter("SELECT 0 DrID, 'select Doctor' as Dr_name UNION ALL SELECT DrID,Dr_name FROM Doctors ", conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CboDrName.DataSource = dt;
                CboDrName.ValueMember = "DrID";
                CboDrName.DisplayMember = "Dr_name";
                




            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtAge.Text == "" || txtmobile.Text==""||txtAddres.Text==""||cbosex.Text=="")
            {
                MessageBox.Show("flease fill the blank text input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Patient_Sp";
                cmd.Parameters.AddWithValue("@id", "");
                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                cmd.Parameters.AddWithValue("@Mobile",txtmobile.Text);
                cmd.Parameters.AddWithValue("@Sex",cbosex.Text);
                cmd.Parameters.AddWithValue("@Address",txtAddres.Text);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@Type", "INSERT");
                cmd.ExecuteNonQuery();
                MessageBox.Show("New patient has been registered", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clearTexbox();
                displaypatientList();
               
                btnsave.Enabled = true;
                btnupdate.Enabled = false;
                btndelete.Enabled = false;
            }
        }

        private void clearTexbox()
        {
            txtname.Clear();
            txtAge.Clear();
            txtmobile.Clear();
            cbosex.Text = "";
            txtAddres.Clear();
        }

        private void displaypatientList()
        {
            using (SqlConnection conn = mainClass.connect())

            {
                SqlDataAdapter DA = new SqlDataAdapter("select p.patientID,Patient_name,mobile,p.sex,p.Address,D.DrID,D.Dr_name,p.AddedDate from patient p inner join Doctors D on D.DrID = p.DrID", conn);
                DataTable dt = new DataTable();
                DA.Fill(dt);
               dgvdisplayPaientList.DataSource = dt;

            }

        }

        private void dgvdisplayPaientList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvdisplayPaientList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            paitientID=(int) dgvdisplayPaientList.CurrentRow.Cells["PatientID"].Value;
            txtname.Text =dgvdisplayPaientList.CurrentRow.Cells[1].Value.ToString();
           txtAge.Text = dgvdisplayPaientList.CurrentRow.Cells[2].Value.ToString();
            txtmobile.Text = dgvdisplayPaientList.CurrentRow.Cells[3].Value.ToString();
            cbosex.Text = dgvdisplayPaientList.CurrentRow.Cells[4].Value.ToString();
            txtAddres.Text = dgvdisplayPaientList.CurrentRow.Cells[5].Value.ToString();
            btnsave.Enabled = false;
            btnupdate.Enabled = true;
            btndelete.Enabled = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtAge.Text == "" || txtmobile.Text == "" || txtAddres.Text == "" || cbosex.Text == "")
            {
                MessageBox.Show("flease fill the blank text input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Patient_Sp";
                cmd.Parameters.AddWithValue("@id", paitientID);
                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                cmd.Parameters.AddWithValue("@Mobile", txtmobile.Text);
                cmd.Parameters.AddWithValue("@Sex", cbosex.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddres.Text);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@Type", "update");
                cmd.ExecuteNonQuery();
                MessageBox.Show("A patient has been updated", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clearTexbox();
                displaypatientList();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;

            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtAge.Text == "" || txtmobile.Text == "" || txtAddres.Text == "" || cbosex.Text == "")
            {
                MessageBox.Show("flease fill the blank text input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "Patient_Sp";
                cmd.Parameters.AddWithValue("@id",paitientID);
                cmd.Parameters.AddWithValue("@Name", txtname.Text);
                cmd.Parameters.AddWithValue("@Age", txtAge.Text);
                cmd.Parameters.AddWithValue("@Mobile", txtmobile.Text);
                cmd.Parameters.AddWithValue("@Sex", cbosex.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddres.Text);
                cmd.Parameters.AddWithValue("@DrID", CboDrName.SelectedValue);
                cmd.Parameters.AddWithValue("@Type", "Delete");
                cmd.ExecuteNonQuery();
                MessageBox.Show("A patient has been Deleted", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clearTexbox();
                displaypatientList();
                btnsave.Enabled = false;
                btnupdate.Enabled = true;
                btndelete.Enabled = true;

            }
        }
    }
}
