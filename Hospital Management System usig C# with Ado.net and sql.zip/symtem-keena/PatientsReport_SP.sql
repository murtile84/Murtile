create procedure PatientsReport_SP
as
select p.patientID,Patient_name,mobile,p.sex,p.Address,D.DrID,D.Dr_name,
p.AddedDate from patient p 
inner join Doctors D 
on D.DrID = p.DrID
