﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hOSPITAL
{
    public partial class frmLogoin : Form
    {
        public frmLogoin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = mainClass.connect())
            {
                SqlCommand cmd = new SqlCommand("select *from users where Username=@Username and Password=@password;", conn);
                cmd.Parameters.AddWithValue("@Username", TxtUsername.Text);
                cmd.Parameters.AddWithValue("@password", txtPassword.Text);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    fRMmain frm = new fRMmain();
                    frm.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("username and password are incorrect", "Error Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
