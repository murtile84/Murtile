﻿namespace hOSPITAL
{
    partial class FrmDoctors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtDrname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbDRosex = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTDrphone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CBOSpeciality = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvdisplayDRSList = new System.Windows.Forms.DataGridView();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Label();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdisplayDRSList)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Blue;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Cambria", 24F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(706, 92);
            this.label1.TabIndex = 120;
            this.label1.Text = "Doctor Details";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtDrname
            // 
            this.txtDrname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDrname.Location = new System.Drawing.Point(173, 111);
            this.txtDrname.Multiline = true;
            this.txtDrname.Name = "txtDrname";
            this.txtDrname.Size = new System.Drawing.Size(381, 20);
            this.txtDrname.TabIndex = 118;
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label2.Location = new System.Drawing.Point(7, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 21);
            this.label2.TabIndex = 119;
            this.label2.Text = "Doctor Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbDRosex
            // 
            this.cbDRosex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDRosex.FormattingEnabled = true;
            this.cbDRosex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbDRosex.Location = new System.Drawing.Point(173, 147);
            this.cbDRosex.Name = "cbDRosex";
            this.cbDRosex.Size = new System.Drawing.Size(381, 21);
            this.cbDRosex.TabIndex = 121;
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label3.Location = new System.Drawing.Point(7, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 21);
            this.label3.TabIndex = 122;
            this.label3.Text = "Sex";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TXTDrphone
            // 
            this.TXTDrphone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TXTDrphone.Location = new System.Drawing.Point(173, 184);
            this.TXTDrphone.Multiline = true;
            this.TXTDrphone.Name = "TXTDrphone";
            this.TXTDrphone.Size = new System.Drawing.Size(381, 20);
            this.TXTDrphone.TabIndex = 123;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label4.Location = new System.Drawing.Point(7, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 21);
            this.label4.TabIndex = 124;
            this.label4.Text = "Mobile";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CBOSpeciality
            // 
            this.CBOSpeciality.FormattingEnabled = true;
            this.CBOSpeciality.Items.AddRange(new object[] {
            "General Practitoner",
            "Cardiologist",
            "Dermatologist",
            "Neurologist",
            "Gynecologist"});
            this.CBOSpeciality.Location = new System.Drawing.Point(173, 220);
            this.CBOSpeciality.Name = "CBOSpeciality";
            this.CBOSpeciality.Size = new System.Drawing.Size(381, 21);
            this.CBOSpeciality.TabIndex = 125;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F);
            this.label5.Location = new System.Drawing.Point(7, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(160, 21);
            this.label5.TabIndex = 126;
            this.label5.Text = "Speciality";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvdisplayDRSList
            // 
            this.dgvdisplayDRSList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvdisplayDRSList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdisplayDRSList.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvdisplayDRSList.Location = new System.Drawing.Point(0, 335);
            this.dgvdisplayDRSList.Name = "dgvdisplayDRSList";
            this.dgvdisplayDRSList.Size = new System.Drawing.Size(706, 137);
            this.dgvdisplayDRSList.TabIndex = 131;
            this.dgvdisplayDRSList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvdisplayDRSList_CellClick);
            // 
            // txtsearch
            // 
            this.txtsearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtsearch.Location = new System.Drawing.Point(126, 306);
            this.txtsearch.Multiline = true;
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(570, 20);
            this.txtsearch.TabIndex = 130;
            // 
            // Search
            // 
            this.Search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Search.Font = new System.Drawing.Font("Tahoma", 12F);
            this.Search.Location = new System.Drawing.Point(11, 305);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(113, 21);
            this.Search.TabIndex = 132;
            this.Search.Text = "Search";
            this.Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.SystemColors.Control;
            this.btndelete.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btndelete.ForeColor = System.Drawing.Color.Red;
            this.btndelete.Location = new System.Drawing.Point(432, 247);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(111, 40);
            this.btndelete.TabIndex = 129;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.SystemColors.Control;
            this.btnupdate.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnupdate.ForeColor = System.Drawing.Color.Blue;
            this.btnupdate.Location = new System.Drawing.Point(304, 247);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(111, 40);
            this.btnupdate.TabIndex = 128;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.SystemColors.Control;
            this.btnsave.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnsave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnsave.Location = new System.Drawing.Point(171, 247);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(111, 40);
            this.btnsave.TabIndex = 127;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // FrmDoctors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 472);
            this.Controls.Add(this.dgvdisplayDRSList);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.CBOSpeciality);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TXTDrphone);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbDRosex);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDrname);
            this.Controls.Add(this.label2);
            this.Name = "FrmDoctors";
            this.Text = "FrmDoctors";
            this.Load += new System.EventHandler(this.FrmDoctors_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvdisplayDRSList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDrname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbDRosex;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTDrphone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox CBOSpeciality;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgvdisplayDRSList;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Label Search;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsave;
    }
}